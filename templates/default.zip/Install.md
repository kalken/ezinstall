# Quick start

1. Boot iso
2. Login with nixos/ezconf
3. Press Autocomplete to generate options
4. Customize settings (And export if you want and save the file somewhere outside the iso)
4.1 Dont forget to press Save!
5. Press Install Nixos (Guided)
6. Reboot and enjoy!

> **Warning:** the install **erases everything on the disk you choose**. Photos, documents, an old Windows, all of it. Make a backup first if there's anything you want to keep.

## What you need

- A computer (or virtual machine) started from the **ezinstall USB stick or disc**
- An **internet connection** (a network cable is easiest)
- A disk you're happy to erase

## Step 1: Start the installer

1. Put the ezinstall USB stick in the computer and start it. If it starts your old system instead, restart and press the boot menu key (often **F12**, **F2**, **Esc** or **Del**) and pick the USB stick.
2. Wait a minute. A window opens on its own showing a page called **ezconf**.

That's the installer. Your setup files are already loaded, so there's nothing to download or copy.

## Step 2 (optional): Change the settings first

Want a different setup than the default (other programs, a different keyboard, and so on)? Do it **now, before you install**. It's much easier than doing it later. If you're happy with the defaults, skip to Step 3.

1. Along the top of the page you'll see **tabs**, one for each topic (Boot, Programs, Services, Settings, Users and so on). Click a tab to see and change its settings.
2. To get help finding settings, click the **↻ Autocomplete** button. It builds a list of every setting and program you can choose from. This needs internet and can take a few minutes. Wait until it finishes. After that, the search box on the page suggests options as you type.
3. Make your changes.
4. **Press the Save button. This step is important.** Nothing you change is kept until you press **Save**. If you skip it, the installer uses the old settings and your changes are lost.

You can come back to any of this after the install too. Your settings page stays available.

## Step 3: Press the install button

1. If you changed any settings in Step 2, make sure you pressed **Save** first.
2. Look at the row of buttons on the page and find the one called **Install Nixos (Guided)**. It sits in the row marked *install mode*.
3. Click it.
4. A text window opens at the bottom. This is normal. It's the installer talking to you.

## Step 4: Answer the questions

The installer will ask you two things:

1. **Which disk to use.** It shows a short list of disks with their size and name. Type the name of the one you want to erase (for example `sda` or `nvme0n1`) and press **Enter**. If you're not sure, pick by size, and double-check: **whichever disk you name here is the one that gets erased.** (You can look at the disks first with **List disks** in **Ezmenu**.)
2. **Are you sure?** Type the same disk name again and press **Enter**. This is your last chance to stop. To cancel, close the window or type anything else.

Then wait. It sets up the disk, downloads what it needs and installs. Lines of text will scroll by. That's normal. **Don't turn the computer off.**

## Step 5: Finish

When you see **"Install finished"**:

1. Remove the USB stick.
2. Restart the computer (Ezmenu, then **Reboot**).
3. Log in with username `default` and password `ezconf`.
4. **Change your password** (Start menu, then System Settings, then Users).

Welcome to your new computer!

## Something went wrong?

| What you see | What to do |
|---|---|
| "Nothing mounted" or an error about the disk | Click **Install Nixos (Guided)** again. It's safe to repeat |
| It stops with a network or download error | Check your internet connection, then click the button again |
| You typed a disk name that doesn't exist, or the two names didn't match | It stops without erasing anything. Click the button and try again |
| Not sure which disk is which | Click **List disks** in Ezmenu to see them all |
| Your changes from Step 2 aren't there after installing | You didn't press **Save** before installing. Make them again on the installed system, press **Save**, then click **Activate Configuration** |
