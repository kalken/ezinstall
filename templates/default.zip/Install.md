# Install

**The install erases the whole disk you choose.** Save anything you want to keep somewhere
else first.

You need the ezinstall USB stick, an internet connection (a cable is easiest) and a disk
that may be erased.

## Steps

1. Start the computer from the USB stick. If your old system starts instead, restart and
   press the boot menu key (often F12, F2, Esc or Del), then choose the USB stick.
2. A page called **eznix** opens. Log in with username `nixos` and password `eznix`.
3. Press **Install Nixos (Guided)**. A text window opens at the bottom of the page.
4. Type the name of the disk to erase (for example `sda` or `nvme0n1`) and press Enter. Type
   it once more to confirm.
5. Wait for **Install finished**. Do not turn the computer off before that.
6. Remove the USB stick and press **Ezmenu**, then **Reboot**.
7. Log in with username `default` and password `eznix`, then change the password (Start
   menu, System Settings, Users).

## Changing the setup first (optional)

Do this before step 3 if you want other programs, another keyboard layout and so on.

1. Press **Autocomplete** and wait for it to finish. The page can then suggest settings and
   programs as you type.
2. Click through the tabs at the top and change what you want. To add a setting, right-click
   and choose **Add option…**.
3. Press **Save**. Without it your changes are not installed.

You can also change all of this after the install.

## If something goes wrong

| What happens | What to do |
|---|---|
| An error about the disk, the network or a download | Check the internet connection and press **Install Nixos (Guided)** again. It is safe to repeat |
| The two disk names did not match | Nothing was erased. Press the button again |
| You don't know which disk is which | Press **Ezmenu**, then **List disks** |
| Your changes are missing after the install | They were not saved. Make them again on the new system, press **Save**, then **Rebuild** |
