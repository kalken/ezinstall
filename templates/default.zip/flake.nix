{
  description = "Template Nixos Setup";
  #! inputs
  inputs = {
    ##! nixpkgs
    nixpkgs.url = "github:NixOS/nixpkgs/nixos-unstable";

    ##! ezconf
    ezconf.url = "github:kalken/ezconf/develop";
    ezconf.inputs.nixpkgs.follows = "nixpkgs";
  };

  #! outputs
  outputs = inputs: {
    nixosConfigurations = {
      default = inputs.nixpkgs.lib.nixosSystem {
        system = "x86_64-linux";
        modules = [
          inputs.ezconf.nixosModules.default

          ##! local config
          ./hardware-configuration.nix
          ./ezconf
          ./plugins
        ];
      };
    };
  };
}
