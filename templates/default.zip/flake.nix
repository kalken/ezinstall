{
  description = "Template Nixos Setup";
  #! inputs
  inputs = {
    ##! nixpkgs
    nixpkgs.url = "github:NixOS/nixpkgs/nixos-unstable";

    ##! eznix
    eznix.url = "github:kalken/eznix";
    eznix.inputs.nixpkgs.follows = "nixpkgs";
  };

  #! outputs
  outputs = inputs: {
    nixosConfigurations = {
      default = inputs.nixpkgs.lib.nixosSystem {
        system = "x86_64-linux";
        modules = [
          inputs.eznix.nixosModules.default

          ##! local config
          ./hardware-configuration.nix
          (inputs.eznix.lib.jsonDir ./eznix)
          ./plugins
        ];
      };
    };
  };
}
