# Your new computer

This folder is a ready-made setup for a desktop computer running NixOS with KDE. You change
it by clicking in a web page called **eznix**, not by editing files.

To install it, follow [INSTALL.md](./INSTALL.md).

## Login

Username `default`, password `eznix`.

Change the password once you are logged in: Start menu, System Settings, Users.

## Changing things later

1. Open http://localhost:9090 in the browser and log in with your username and password.
2. Change what you want and press **Save**.
3. Press **Rebuild**. Your changes are in use when it finishes.

The other buttons:

| Button | What it does |
|---|---|
| **Update** | Fetches newer versions of your programs. Press **Rebuild** after it |
| **List** | Shows the earlier versions of your system. You can start any of them from the menu shown when the computer starts |
| **Clear** | Removes those earlier versions to free disk space |

## The files

| | |
|---|---|
| `eznix/` | Your settings. This is what the page edits |
| `plugins/` | For add-ons. Empty to begin with |
| `flake.nix` | Ties it all together |
| `hardware-configuration.nix` | Describes your computer. Made during the install |
