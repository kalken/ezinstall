# Your new computer setup

This is a ready-made setup for a Linux desktop running KDE (the operating system is called **NixOS**). You don't need to know anything about Linux to use it. Follow the steps in [Install.md](./Install.md) and it does the hard parts for you.

## Your login

| | |
|---|---|
| Username | `default` |
| Password | `ezconf` |

Everyone who reads this knows that password, so **change it as soon as you're logged in** (Start menu, then System Settings, then Users).

## Good to know

- The settings page (ezconf) stays available after installing, you can find it in the application menu, so you can change your setup by clicking instead of typing.
- There is an option to install as an app in the right side of the address bar if you use chromium based browser.

## What's in this folder

You don't need to touch any of this. It's here for the curious.

| Item | What it's for |
|---|---|
| `ezconf/` | Your settings, one file per topic (boot, disks, users, and so on). You edit these by clicking in the ezconf page, not by hand |
| `plugins/` | Extra add-ons. Empty by default |
| `flake.nix` and `flake.lock` | The recipe that ties everything together |
| `hardware-configuration.nix` | A description of your computer's parts. It gets re-created for your computer during install |

Ready? Go to read Install.md
